<?php

use yii\helpers\Html;
use app\models\User;
use yii\grid\GridView;
use yii\helpers\ArrayHelper;
use yii\helpers\Url;
use yii\bootstrap\Modal;

/* @var $this yii\web\View */
/* @var $searchModel app\models\UploadolahSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = 'Upload File Split Susenas';
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="uploadolah-index">

    <h1><?= Html::encode($this->title) ?></h1>

    
    <p>
        <?= Html::button('Upload', ['value'=>Url::to('index.php?r=uploadolah/upload'),'class' => 'btn btn-success','id'=>'modalButton']) ?>
    </p>

    <div class="text-left">
        <?php
            Modal::begin([
                'header'=>'<h4>Upload File Split</h4>',
                'id'=>'modal',
                'size'=>'modal-lg',
            ]);

            echo "<div id='modalContent'></div>";

            Modal::end();
        ?>
                      
    <?php //echo $this->render('_search', ['model' => $searchModel]); ?>

    <?= GridView::widget([
        'dataProvider' => $dataProvider,
        'filterModel' => $searchModel,
        'columns' => [
            ['class' => 'yii\grid\SerialColumn'],

            //'idpost',
            [
                'attribute' => 'Nama Petugas',
                'value' => 'user.fullname',
                'filter' => Html::activeDropDownList($searchModel, 'id', ArrayHelper::map(User::find()->asArray()->all(), 'id','fullname'),['class'=>'form-control','prompt' => 'Nama Petugas']),
            ],
            //'filesplit',
            [
                'attribute'=>'filesplit',
                'format'=>'html',
                'value'=>function($model){
                    return Html::a($model->filesplit, ['download','filesplit'=> $model->filesplit]);
                }
            ],
            //'keterangan',
            'dateupload',
            //'id',

            ['class' => 'yii\grid\ActionColumn'],
        ],
    ]); ?>


</div>
