<?php
use yii\helpers\Html;
use yii\grid\GridView;
use app\models\Instansi;
use yii\helpers\ArrayHelper;

$this->title = 'Rekap SPO';
$this->params['breadcrumbs'][] = $this->title;
?>


<h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Tambah Peserta', ['create'], ['class' => 'btn btn-success']) ?>
        <?= Html::a('Tampilkan Detail', ['index'], ['class' => 'btn btn-success']) ?>
    </p>
<h4 style="background-color:#e1e1e1">
<p>Total <b><?= count($query2) ?></b> Instansi - dari <i><b><?= count($query1) ?></b> Instansi </i></p>
<p>Total 
	<b><?php foreach ($query3 as $dataprog): ?>
			<tr>
				<td> <?= $dataprog['grandtotal'] ?></td>
			</tr>
		<?php endforeach; ?>
	</b>
Peserta</p>
</h4>

<table class="table table-bordered table-striped">
	<thead style ='background-color:#000000'>
		<tr style="align-items: center;">
			<!-- <td>Kode Instansi</td> -->
			<td><b style="color: #ffffff">Nama Instansi</b></td>
			<td><b style="color: #ffffff">Total Peserta SPO</b></td>
		</tr>
	</thead>
	<tbody>
	<?php foreach ($results as $dataprogres): ?>	
		<tr>
			<!-- <td> <?= $dataprogres['id_instansi'] ?></td> -->
			
			<td> <?= $dataprogres['nama_instansi'] ?></td>

			<td> <?= $dataprogres['test'] ?></td>
		</tr>
	<?php endforeach; ?>
	</tbody>
</table>



            