<?php

Yii::setAlias('@imgPath', 'C:\xampp\htdocs\kolomdata\frontend\web\uploads\\');
Yii::setAlias('@imgUrl', 'http://localhost:8080/kolomdata/frontend/web/uploads/');
return [
];
